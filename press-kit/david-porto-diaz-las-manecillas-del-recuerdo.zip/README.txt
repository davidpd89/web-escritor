KIT DE PRENSA — DAVID PORTO DÍAZ / LAS MANECILLAS DEL RECUERDO
===================================================================

Autor: David Porto Díaz
Web: https://davidportodiaz.com/
Contacto de prensa: [https://davidportodiaz.com/prensa.html#contacto](https://davidportodiaz.com/prensa.html#contacto)

Título: Las manecillas del recuerdo
Editorial: Monza Ediciones
Fecha de publicación: 2026-09-03
ISBN: 979-8-90514-935-1
Extensión de maqueta: 272 páginas
PVP comunicado: 15.99 EUR
Géneros/posicionamiento: Novela coral, Ficción especulativa, Narrativa familiar

SINOPSIS BREVE
Manuel comparte con su nieto Tomás las historias de un reloj que ha pasado por distintas manos y generaciones. Cuando alguien inesperado regresa del pasado, el destino de la familia cambia.

BIO BREVE
Escritor gallego residente en Madrid. Autor de Las manecillas del recuerdo (Monza Ediciones, publicada el 3 de septiembre de 2026) y Samuel entre mundos (Libros Indie, 2025). Ganador del Primer Premio — XII Certamen de Microrrelatos «De amor» · Letras Como Espada 2026 (microrrelato «Al otro lado») y del I Concurso de microrrelatos sobre hombres lobo «Aullidos en papel» · Diversidad Literaria 2026.

CONTENIDO DEL PAQUETE
- media/david-porto-diaz-retrato-editorial-prensa.webp: Retrato editorial del autor
- media/las-manecillas-del-recuerdo-visual-prensa-horizontal.webp: Visual horizontal de prensa
- media/las-manecillas-del-recuerdo-mockup-3d.webp: Mockup 3D del libro
- datos/: fichas JSON usadas para generar este paquete
- CHECKSUMS_SHA256.txt: hashes de integridad
- MANIFEST.json: manifiesto exacto del paquete

USO
Material preparado para información, reseñas, entrevistas, librerías, bibliotecas y cobertura editorial.
No alterar la portada ni atribuir al autor/editorial datos que no aparezcan en las fichas incluidas.
Para una versión actualizada, usar siempre la página oficial de prensa.

Página de prensa: [https://davidportodiaz.com/prensa.html](https://davidportodiaz.com/prensa.html)
