KIT DE PRENSA — DAVID PORTO DÍAZ / LAS MANECILLAS DEL RECUERDO
===================================================================

Autor: David Porto Díaz
Web: https://davidportodiaz.com
Contacto de prensa: press@example.com

Título: Las manecillas del recuerdo
Editorial: Editorial Ejemplo
Fecha de publicación: 2026-01-01
ISBN: 9780000000000
Extensión de maqueta: 320 páginas
PVP comunicado: 15 EUR
Géneros/posicionamiento: 

SINOPSIS BREVE


BIO BREVE
Autor de ejemplo.

CONTENIDO DEL PAQUETE
- datos/: fichas JSON usadas para generar este paquete
- CHECKSUMS_SHA256.txt: hashes de integridad
- MANIFEST.json: manifiesto exacto del paquete

USO
Material preparado para información, reseñas, entrevistas, librerías, bibliotecas y cobertura editorial.
No alterar la portada ni atribuir al autor/editorial datos que no aparezcan en las fichas incluidas.
Para una versión actualizada, usar siempre la página oficial de prensa.

Página de prensa: https://davidportodiaz.com/prensa
